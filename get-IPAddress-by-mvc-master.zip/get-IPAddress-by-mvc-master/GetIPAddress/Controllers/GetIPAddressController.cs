﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace GetIPAddress.Controllers
{
    public class GetIPAddressController : Controller
    {
        // GET: GetIPAddress
        public ActionResult Index()
        {
            return View();
        }
    }
}